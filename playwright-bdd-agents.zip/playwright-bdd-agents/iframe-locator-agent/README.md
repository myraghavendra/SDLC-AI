# Iframe Locator Agent — Reliable Locators Inside Nested Iframes

Answers "how do we find the right locator when a screen has iframes
inside iframes?" Same two-tier shape as `app-context-agent/`: Copilot
Chat can't browse the live app on its own, so a plain Playwright script
captures the real frame structure first, and the Copilot agent only
reads what was captured — it never guesses a frame name or nesting depth.

## Why this is a separate agent from `/ui-test-agent` and `/app-context-builder`

`ui-element-map.md` (built by `/app-context-builder`) captures the
**top-level document** only — it doesn't descend into `<iframe>`
content, and Playwright locators can't reach into a frame without an
explicit `frameLocator()` per nesting level. Screens with widgets
embedded via iframe (carrier/label widgets, legacy screens embedded in
the new UI, third-party pickers) need this separate walk, and the
resulting chain needs its own home (`iframe-locator-map.md`) so it isn't
mixed with plain top-level selectors.

## Flow

```
Live WMS app (test account)
        │
        ▼
capture-iframe-map.ts   (plain Playwright, not AI)
        │  logs in, walks a list of screens, recursively walks
        │  EVERY frame on each screen (frames nested inside frames
        │  included), records the stable selector for each iframe
        │  element and the data-testid elements inside it
        ▼
context-sources/iframe-snapshots/*.json
        │
        ▼
/iframe-locator-agent   (Copilot agent — only reads the captured files)
        │
        ▼
.github/knowledge/iframe-locator-map.md
   - real frameLocator() chains per element, cited from the capture
   - flags any iframe with no stable name/title/data-testid/src
   - shared frames/frameChainResolver.ts helper proposed/kept in sync
```

`/playwright-bdd-test-agent` and `/ui-test-agent` should use this map
(and the `frameChainResolver.ts` helper) instead of re-deriving frame
selectors per test.

## Setup
1. Set env vars for a **dedicated test/QA account** (never a real user's
   login, never hardcoded in the script) — same vars as
   `capture-app-snapshots.ts`:
   ```
   WMS_BASE_URL=https://your-app.example.com
   WMS_LOGIN_PATH=/login
   WMS_TEST_USERNAME=...
   WMS_TEST_PASSWORD=...
   ```
2. Edit the `SCREENS` list in `capture-iframe-map.ts` to the screens
   that actually embed iframes in your app — no need to list screens
   with no frames, `/ui-test-agent` already covers those.
3. Add `context-sources/iframe-snapshots/` to `.gitignore` if captured
   frame content could include real customer/order data — run against a
   sandbox/staging environment with synthetic data, not production.
4. Run the capture script, then run `/iframe-locator-agent` in Copilot
   Chat for the specific element/screen you need a locator for.
5. Re-run the capture whenever the app's iframe structure changes
   (widget swapped, a new nesting level added, frame renamed) — this is
   a snapshot, not a live sync.

## If you can't run the capture script right now
`/iframe-locator-agent` can also work from a one-off frame dump you run
and paste in yourself — see Section 3 of its prompt file. That's meant
for a single quick lookup, not a substitute for the real capture when a
screen's frames will be used repeatedly.

## Files in this folder
| File | Role |
|---|---|
| `capture-iframe-map.ts` | Playwright script — logs in, recursively walks nested iframes per screen (not AI) |
| `iframe-locator-agent.prompt.md` | Copilot agent — builds `.github/knowledge/iframe-locator-map.md` and the `frameChainResolver.ts` helper from captures |

Same discovery caveat as the other extra folders: copy
`iframe-locator-agent.prompt.md` into `.github/prompts/` (or register
this folder as an extra prompt location) to actually run it as a slash
command — see the root `README.md`.
