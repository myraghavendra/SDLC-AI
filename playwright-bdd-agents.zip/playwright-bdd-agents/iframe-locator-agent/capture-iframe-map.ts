/**
 * Iframe map capture — Tier 1 of the Iframe Locator Agent.
 *
 * This is plain Playwright automation, NOT an AI agent. It logs into the
 * live WMS app with a test account, walks a list of screens, and for each
 * one recursively walks EVERY frame (including iframes nested inside
 * other iframes) to record the exact frame chain needed to reach it and
 * what's inside it. The Iframe Locator Agent (Copilot) reads those files
 * afterward — Copilot itself never talks to the live app.
 *
 * Same credential rule as capture-app-snapshots.ts (see app-context-agent/):
 * env vars only, dedicated test/QA account, never hardcoded, never a real
 * user's login.
 *
 *   WMS_BASE_URL=https://your-app.example.com
 *   WMS_LOGIN_PATH=/login
 *   WMS_TEST_USERNAME=...
 *   WMS_TEST_PASSWORD=...
 *
 * Run: npx playwright test capture-iframe-map.ts
 * (or `npx ts-node capture-iframe-map.ts` if run standalone — adjust the
 * runner to match how this repo already invokes Playwright.)
 */

import { chromium, Frame, Page } from "playwright";
import * as fs from "fs";
import * as path from "path";

const BASE_URL = process.env.WMS_BASE_URL;
const LOGIN_PATH = process.env.WMS_LOGIN_PATH || "/login";
const USERNAME = process.env.WMS_TEST_USERNAME;
const PASSWORD = process.env.WMS_TEST_PASSWORD;

if (!BASE_URL || !USERNAME || !PASSWORD) {
  throw new Error(
    "Set WMS_BASE_URL, WMS_TEST_USERNAME, WMS_TEST_PASSWORD env vars before running. " +
      "Never hardcode credentials in this file."
  );
}

// Edit this list to match the screens that actually embed iframes in your
// app (widgets, third-party pickers, legacy screens embedded via iframe,
// payment/label-printing widgets, etc). No point capturing screens that
// have no frames — /ui-test-agent already covers those.
const SCREENS: { name: string; path: string }[] = [
  { name: "outbound-pack-station", path: "/outbound/pack-station" },
  { name: "returns-rma", path: "/returns/rma" },
];

const OUT_DIR = path.join(__dirname, "..", "..", "context-sources", "iframe-snapshots");

interface FrameNode {
  chainSelector: string[]; // e.g. ["iframe[name=\"carrierWidget\"]", "iframe[title=\"Label Preview\"]"]
  url: string;
  name: string | null;
  title: string | null;
  testIdElements: { testId: string | null; tag: string; role: string | null; text: string }[];
  children: FrameNode[];
}

// Build a stable CSS selector for the <iframe> element backing a given
// Frame, preferring attributes that don't change between runs.
async function frameOwnerSelector(frame: Frame): Promise<string> {
  const owner = await frame.frameElement();
  const attrs = await owner.evaluate((el) => ({
    name: el.getAttribute("name"),
    title: el.getAttribute("title"),
    testId: el.getAttribute("data-testid"),
    id: el.getAttribute("id"),
    src: el.getAttribute("src"),
  }));
  if (attrs.testId) return `iframe[data-testid="${attrs.testId}"]`;
  if (attrs.name) return `iframe[name="${attrs.name}"]`;
  if (attrs.title) return `iframe[title="${attrs.title}"]`;
  if (attrs.id) return `iframe[id="${attrs.id}"]`;
  if (attrs.src) {
    // Use a stable path segment, not the full src (query strings/tokens
    // are often dynamic per session).
    const stablePath = attrs.src.split("?")[0];
    return `iframe[src*="${stablePath}"]`;
  }
  // Last resort — flagged in the output so the agent can warn about it
  // instead of silently emitting a positional selector.
  return "iframe /* UNSTABLE: no name/title/data-testid/id/src found */";
}

async function walkFrame(frame: Frame, chainSelector: string[]): Promise<FrameNode> {
  const testIdElements = await frame
    .$$eval("[data-testid]", (els) =>
      els.map((el) => ({
        testId: el.getAttribute("data-testid"),
        tag: el.tagName.toLowerCase(),
        role: el.getAttribute("role"),
        text: (el.textContent || "").trim().slice(0, 80),
      }))
    )
    .catch(() => []); // cross-origin frames can throw; record empty rather than fail the whole walk

  const children: FrameNode[] = [];
  for (const child of frame.childFrames()) {
    const childSelector = await frameOwnerSelector(child);
    children.push(await walkFrame(child, [...chainSelector, childSelector]));
  }

  return {
    chainSelector,
    url: frame.url(),
    name: frame.name() || null,
    title: null,
    testIdElements,
    children,
  };
}

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });

  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page: Page = await context.newPage();

  await page.goto(`${BASE_URL}${LOGIN_PATH}`);
  await page.getByLabel(/username|email/i).fill(USERNAME!);
  await page.getByLabel(/password/i).fill(PASSWORD!);
  await page.getByRole("button", { name: /log in|sign in/i }).click();
  await page.waitForLoadState("networkidle");

  for (const screen of SCREENS) {
    try {
      await page.goto(`${BASE_URL}${screen.path}`);
      await page.waitForLoadState("networkidle");

      const topFrames: FrameNode[] = [];
      for (const child of page.mainFrame().childFrames()) {
        const selector = await frameOwnerSelector(child);
        topFrames.push(await walkFrame(child, [selector]));
      }

      const snapshot = {
        screen: screen.name,
        url: page.url(),
        capturedAt: new Date().toISOString(),
        frameCount: countFrames(topFrames),
        frames: topFrames,
      };

      const outFile = path.join(OUT_DIR, `${screen.name}.json`);
      fs.writeFileSync(outFile, JSON.stringify(snapshot, null, 2));
      console.log(
        `Captured ${screen.name} -> ${outFile} (${snapshot.frameCount} frame(s), incl. nested)`
      );
    } catch (err) {
      console.error(`Failed to capture iframe map for ${screen.name}:`, err);
    }
  }

  await browser.close();
}

function countFrames(nodes: FrameNode[]): number {
  return nodes.reduce((sum, n) => sum + 1 + countFrames(n.children), 0);
}

main();
