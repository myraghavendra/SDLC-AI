# Playwright BDD Agents — Gherkin Test Generation + Iframe Locators

Two agents, kept together in this folder because they're meant to be
used as a pair: `/playwright-bdd-test-agent` generates the Gherkin
`.feature` files and `playwright-bdd` step definitions, and
`/iframe-locator-agent` is what it (and `/ui-test-agent`) should defer to
whenever a target element lives inside an iframe — including a frame
nested inside another frame.

## Contents
| Path | Role |
|---|---|
| `playwright-bdd-test-agent.prompt.md` | Copilot agent — generates `.feature` files + `playwright-bdd` step definitions under `features/` |
| `iframe-locator-agent/` | Capture script + Copilot agent that resolve reliable `frameLocator()` chains for nested/inherited iframes — see its own README |

## Important: this folder alone is NOT auto-discovered by Copilot Chat

Same caveat as `copilot-agents-extended/`, `knowledge-center-agents/`,
and `app-context-agent/`: VS Code's Copilot Chat only scans
`.github/prompts/` by default for slash-command prompt files. To
actually use `/playwright-bdd-test-agent` and `/iframe-locator-agent`,
pick one:

**Option A — simplest, guaranteed to work now**
Copy `playwright-bdd-test-agent.prompt.md` and
`iframe-locator-agent/iframe-locator-agent.prompt.md` into
`.github/prompts/` next to the other WMS agents. This folder then
becomes your source/reference copy.

**Option B — keep them separate, register the extra folder**
If your VS Code + Copilot Chat version supports
`chat.promptFilesLocations` (or an equivalent setting for additional
prompt file locations), point it at this folder instead of moving files.
See `copilot-agents-extended/README.md` for the same option in more
detail — availability depends on your Copilot Chat extension version.

Either way, both agents rely on `.github/copilot-instructions.md` for
repo conventions (WMS glossary, `playwright-bdd` file layout, iframe
locator rules) — keep that file accurate as the suite grows.

## How these fit the rest of the flow

See the root `.github/TESTING-FLOW.md` for the full diagram. Short
version: `/iframe-locator-agent` runs first for any screen with iframes
(after its own `capture-iframe-map.ts` capture step), producing
`.github/knowledge/iframe-locator-map.md`. `/playwright-bdd-test-agent`
then reads that map (plus `.github/knowledge/ui-element-map.md` and
`functional-knowledge-base.md`) when generating scenarios — it does not
re-derive frame selectors on its own.
