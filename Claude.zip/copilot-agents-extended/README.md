# Extended Copilot Agents

Thirteen more Copilot Chat agents, kept in this separate folder from the
WMS-specific ones in `.github/prompts/` so it's clear which are
WMS-test-flow-specific vs. general engineering agents usable in any repo.

## Agents in this folder
| Command | File | Stage |
|---|---|---|
| `/ac-reviewer-agent` | `ac-reviewer-agent.prompt.md` | Before test planning — checks AC quality |
| `/test-coverage-gap-agent` | `test-coverage-gap-agent.prompt.md` | Finds untested code paths |
| `/code-review-agent` | `code-review-agent.prompt.md` | Before opening a PR |
| `/pr-description-agent` | `pr-description-agent.prompt.md` | Writes the PR title/summary/test plan |
| `/refactor-agent` | `refactor-agent.prompt.md` | Structural cleanup, no behavior change |
| `/docs-agent` | `docs-agent.prompt.md` | Keeps README/JSDoc/API docs in sync |
| `/accessibility-test-agent` | `accessibility-test-agent.prompt.md` | axe-core checks in Playwright specs |
| `/performance-load-test-agent` | `performance-load-test-agent.prompt.md` | k6/Artillery scripts for hot endpoints |
| `/api-contract-drift-agent` | `api-contract-drift-agent.prompt.md` | Catches API spec vs. test/type drift |
| `/security-review-agent` | `security-review-agent.prompt.md` | OWASP-style review of a diff |
| `/dependency-risk-agent` | `dependency-risk-agent.prompt.md` | Flags risky outdated/vulnerable deps |
| `/ci-failure-triage-agent` | `ci-failure-triage-agent.prompt.md` | Buckets a whole CI run's failures |
| `/changelog-agent` | `changelog-agent.prompt.md` | Drafts release notes from merged PRs |

## Important: this folder alone is NOT auto-discovered by Copilot Chat

VS Code's Copilot Chat only scans `.github/prompts/` by default for
slash-command prompt files. To actually use the agents in *this* folder,
pick one:

**Option A — simplest, guaranteed to work now**
Copy (or move) these `.prompt.md` files into `.github/prompts/` next to
the WMS agents. They'll show up under `/` immediately, same as the
existing six. This folder then just becomes your source/reference copy.

**Option B — keep them separate, register the extra folder**
In newer VS Code + Copilot Chat versions there's a setting to add
additional prompt file locations (e.g. `chat.promptFilesLocations`) so
you can point it at `copilot-agents-extended/` without moving files.
Availability depends on your Copilot Chat extension version — check
VS Code Settings by searching "prompt files" ; if you don't see an option
to add extra locations, use Option A instead.

Either way, these agents also rely on `.github/copilot-instructions.md`
for repo conventions — several (code-review, docs, security-review,
dependency-risk) are general-purpose and work in any repo, but read that
file for WMS-specific context where relevant (e.g. accessibility and
performance agents reference WMS scanner/handheld usage).
