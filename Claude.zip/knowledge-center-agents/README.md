# Knowledge Center Agents

Two agents that turn existing test cases (Excel + Jira/Xray) into a
functional Knowledge Center — a queryable reference plus a navigable
Mermaid mind map — and wire that context into the test-generation
agents in `.github/prompts/` and `copilot-agents-extended/`. Built
entirely on GitHub Copilot Chat, same as everything else in this repo.

## What it actually does
- `/knowledge-map-builder` — reads test case exports, extracts the
  **business rules/behaviors** those test cases prove (not just a copy
  of the test cases), and writes:
  - `.github/knowledge/functional-knowledge-base.md` — the detailed,
    source-cited reference. This is the real knowledge base.
  - `.github/knowledge/knowledge-map.md` — a Mermaid `mindmap` diagram
    for navigation/orientation (GitHub renders Mermaid natively in
    markdown, so this is viewable directly on GitHub, no extra tool).
- `/knowledge-query-agent` — answers "how does the product behave"
  questions strictly from that knowledge base, always citing the source
  test case/Jira key, and says "not documented" rather than guessing
  when the answer isn't there.
- The WMS test-generation agents (`test-orchestrator`, `api-test-agent`,
  `ui-test-agent`, `ac-reviewer-agent`, `test-case-agent`) were updated
  to consult the knowledge base before generating/reviewing new test
  cases, so new tests stay consistent with documented behavior.

## Important limitations — read before relying on this

**Copilot cannot read `.xlsx` files directly.** Export your Excel test
cases to CSV first (File → Save As → CSV) and place them under
`knowledge-sources/excel/`. This is a real constraint of building on
Copilot only, not a bug — there's no Excel-parsing tool available inside
Copilot Chat itself.

**Copilot has no built-in live Jira connection.** Two options:
1. **Export from Jira** (Issues → Export → CSV, or an Xray Test
   Repository export) into `knowledge-sources/jira/`, and re-run
   `/knowledge-map-builder` whenever test cases change. This is the
   reliable path and needs no extra setup.
2. **Connect a Jira/Atlassian MCP server** in VS Code (Copilot Chat
   supports MCP tools) if your org allows it — then the builder agent
   can query Jira directly instead of working from exports. This is
   optional and depends on what your org permits; don't assume it's
   available without checking with your Copilot/Jira admin.

Either way, this is **not a live sync** — the knowledge base is only as
current as the last time you ran `/knowledge-map-builder`. Re-run it
after significant test-case additions or Jira/Excel updates.

**The "mind map" is a Mermaid diagram in markdown, not an interactive
mind-mapping app.** That's the Copilot-only-compatible way to get a
visual, navigable map without introducing a separate tool — it renders
directly on GitHub and in VS Code's markdown preview.

## Setup
1. Create `knowledge-sources/excel/` and `knowledge-sources/jira/` in
   your WMS test repo; drop in your CSV/JSON exports.
2. Run `/knowledge-map-builder` in Copilot Chat. Review the summary of
   what it added/flagged.
3. Check `.github/knowledge/functional-knowledge-base.md` and
   `.github/knowledge/knowledge-map.md` — this is what every other agent
   now treats as ground truth, so it's worth a human read-through before
   trusting it.
4. From then on: ask `/knowledge-query-agent` functional questions
   directly, and the test-generation agents will pull from it
   automatically when you run them.

## Files in this folder
| File | Role |
|---|---|
| `knowledge-map-builder.prompt.md` | Builds/updates the knowledge base + mind map from test case exports |
| `knowledge-query-agent.prompt.md` | Answers functional questions from the knowledge base only |

Same discovery caveat as `copilot-agents-extended/`: Copilot Chat only
auto-discovers slash commands from `.github/prompts/` by default. Copy
these two files there (or register this folder as an extra prompt
location) to actually use them — see the root `README.md`.
