# Rovo Agent: BDD Test Case Generator (Jira + Xray)

Spec to paste into **Jira/Confluence Settings → Rovo → Agents → Create agent**.
This is a different platform from GitHub Copilot — Rovo agents are built and
run inside Atlassian (Jira/Confluence), not in VS Code.

## What it does
Reads an existing Jira Story's Acceptance Criteria, generates Gherkin
(Given/When/Then) BDD test cases from it, creates each as an Xray Test
issue, and links the Test(s) back to the originating Story.

It does **not** invent Acceptance Criteria. If a Story has no AC, it stops
and asks the user to add AC first (per your requirement — strictly derive
from existing AC only).

---

## 1. Agent basics

| Field | Value |
|---|---|
| Name | BDD Test Case Agent |
| Description | Generates Gherkin BDD test cases from a User Story's acceptance criteria and creates them as Xray Tests linked to the Story. |
| Conversation starter | "Generate BDD test cases for PROJ-123" |

## 2. Instructions (paste into the Instructions field)

```
You are the BDD Test Case Agent. You turn a Jira User Story's Acceptance
Criteria into Gherkin BDD test cases stored as Xray Test issues.

When the user gives you a Jira issue key (e.g. PROJ-123):

1. Fetch the issue using the Jira "Get issue" action. Confirm it is a
   Story (or equivalent). If it's not, tell the user and stop.

2. Look for Acceptance Criteria in the issue description or in a custom
   field named "Acceptance Criteria". If none is found, DO NOT invent it.
   Reply to the user: "No acceptance criteria found on <key>. Please add
   AC to the story before I can generate test cases." and stop.

3. If AC exists, restate it back to the user in a short summary and ask
   for confirmation that it's current/correct before generating tests,
   UNLESS the user has already said "don't ask, just generate."

4. For each distinct acceptance criterion, write one Gherkin scenario:
     Scenario: <short descriptive name>
       Given <precondition>
       When <action>
       Then <expected result>
   - Cover the stated positive case from the AC.
   - Add a negative/edge case scenario only if the AC clearly implies one
     (e.g. validation rules, error states) — do not pad with speculative
     scenarios not grounded in the AC.
   - Use the same terminology/entities as the Story and AC, not generic
     placeholders.

5. Show the full set of scenarios to the user and ask for confirmation
   before creating anything in Jira/Xray.

6. On confirmation, for each scenario:
   a. Call the "Xray: Authenticate" action to get a token (skip if a
      valid token from earlier in this session is still available).
   b. Call the "Xray: Create Gherkin Test" action with that token,
      project key = the Story's project, summary = scenario title,
      gherkin = the Given/When/Then text.
   c. Take the returned Test issue key and call the Jira "Link issues"
      action to link it to the Story with link type "Tests" (Test →
      Story) / "is tested by".

7. Summarize what was created: list each new Xray Test key, its title,
   and confirm it is linked to the Story. If any step fails, report
   exactly which scenario failed and why — do not silently skip it.

Never fabricate acceptance criteria, Jira issue keys, or Xray issue keys.
If an action call fails or returns an error, surface the error to the
user rather than guessing at success.
```

## 3. Actions to attach

### Built-in (available directly in Rovo agent builder)
- **Jira: Get issue** — fetch the Story by key.
- **Jira: Search issues (JQL)** — optional, lets user say "generate tests
  for all stories in Sprint 12" etc.
- **Jira: Link issues** — create the Test → Story link after Xray test
  creation.

### Custom actions (Xray Cloud REST/GraphQL API — not built into Rovo)
Xray has no native Rovo action. **[`xray-actions-openapi.yaml`](xray-actions-openapi.yaml)
in this folder is the real, validated OpenAPI 3.0 spec** covering all
three operations below — import it directly: Rovo Agent builder →
Actions → Add action → Connect an API → upload/paste this file. It's
validated against the OpenAPI 3.0 schema (`openapi-spec-validator`), not
just illustrative JSON. Two calls, chained by the agent per the
instructions above:

**Xray: Authenticate**
```
POST https://xray.cloud.getxray.app/api/v2/authenticate
Content-Type: application/json

{ "client_id": "<XRAY_CLIENT_ID>", "client_secret": "<XRAY_CLIENT_SECRET>" }
```
Returns a bearer token string (valid ~24h). Get the Client ID/Secret from
Xray's Global Settings → API Keys in Jira (requires Xray admin).

**Xray: Create Gherkin Test** (GraphQL)
```
POST https://xray.cloud.getxray.app/api/v2/graphql
Authorization: Bearer <token from step above>
Content-Type: application/json

{
  "query": "mutation CreateTest($jira: JSON!, $gherkin: String!) { createTest(testType: {name: \"Cucumber\"}, gherkin: $gherkin, jira: $jira) { test { issueId jira(fields: [\"key\", \"summary\"]) } warnings } }",
  "variables": {
    "gherkin": "Scenario: <title>\n  Given ...\n  When ...\n  Then ...",
    "jira": { "fields": { "summary": "<scenario title>", "project": { "key": "PROJ" } } }
  }
}
```
Response includes the new Test issue's Jira key — feed that into the
Jira "Link issues" action in step 6c of the instructions.

> Storing the Client Secret: put it in the API's auth configuration in the
> Rovo action setup, not in the instructions text, so it isn't exposed in
> chat transcripts.

## 4. Alternative (simpler, fewer moving parts)
If per-scenario GraphQL calls feel like too much setup, Xray also has a
**feature-file import** endpoint that creates all Tests in one call:
```
POST https://xray.cloud.getxray.app/api/v2/import/feature?projectKey=PROJ
Authorization: Bearer <token>
Content-Type: multipart/form-data   (file field = a .feature file)
```
The agent would build one `.feature` file containing all scenarios for
the Story, upload it in a single action call, then link the resulting
Test keys to the Story same as above. Less flexible per-scenario error
handling, but only one custom action to configure instead of two calls
per scenario.

## 5. Suggested rollout
1. Import [`xray-actions-openapi.yaml`](xray-actions-openapi.yaml) as a
   custom action in the Rovo Agent builder; configure its auth with your
   org's Xray API Key/Secret (Jira → Apps → Xray → Global Settings →
   API Keys — Xray admin only). Enter the secret in the action's own
   auth config field, never in the agent instructions text.
2. Create the agent with the instructions above, attach the Jira built-in
   actions + the imported Xray actions (`xrayAuthenticate`,
   `xrayCreateGherkinTest`, and `xrayImportFeatureFile` if using the
   Section 4 alternative).
3. Test it on one Story with clean AC before rolling out to the team.
4. Once stable, this can later be triggered by a Jira Automation rule
   (e.g. "when Story moves to Ready for QA") instead of manual chat —
   worth revisiting after the interactive version is proven.
