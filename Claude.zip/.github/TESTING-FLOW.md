# WMS Test Agent Orchestration Flow

Five Copilot Chat agents, run in sequence from VS Code (see repo `README.md`
for one-time setup). GitHub Copilot Chat doesn't auto-chain agents, so you
invoke each with its slash command; each agent's instructions tell you
which one to run next.

```
 Excel + Jira test cases          Live WMS app (test account)
            │                                │
            ▼                                ▼
   /knowledge-map-builder          capture-app-snapshots.ts (Playwright,
   (run once, then re-run           not AI — logs in, walks screens)
    as test cases change)                    │
            │                                ▼
            ▼                      /app-context-builder
 .github/knowledge/                          │
 functional-knowledge-base.md                ▼
 + knowledge-map.md (mind map)     .github/knowledge/ui-element-map.md
            │                                │
            │  (consulted by every agent below — functional rules from
            │   the left, real selectors from the right;
            │   also queryable directly via /knowledge-query-agent)
            ▼
 Use case / User Story + AC
            │
            ▼
   /test-orchestrator
   - classifies WMS module
   - splits into API vs UI vs Both scenarios
   - outputs a test plan table
            │
            ├──────────────┬───────────────────┐
            ▼              ▼                    ▼
  /test-data-agent   /api-test-agent      /ui-test-agent
  (if new fixtures   (Axios specs,        (Playwright specs,
   needed first)      tests/api/**)        Page Object Model,
                                            tests/ui/**)
            │              │                    │
            └──────────────┴─────────┬──────────┘
                                      ▼
                          npx playwright test
                          (run via CI / GitHub Actions)
                                      │
                                 test fails?
                                      ▼
                          /self-healing-agent
                    (paste failing test + stack trace;
                     classifies stale selector / stale
                     API contract / regression / flaky,
                     proposes the smallest fix)
```

## Agents
| Command | File | Role |
|---|---|---|
| `/knowledge-map-builder` | `knowledge-center-agents/knowledge-map-builder.prompt.md` | Build/update the knowledge base + mind map from Excel/Jira test cases |
| `/knowledge-query-agent` | `knowledge-center-agents/knowledge-query-agent.prompt.md` | Answer functional questions from the knowledge base only |
| `/app-context-builder` | `app-context-agent/app-context-builder.prompt.md` | Build `ui-element-map.md` from live-app screen captures |
| `/test-orchestrator` | `.github/prompts/test-orchestrator.prompt.md` | Classify use case → test plan (no code) |
| `/test-data-agent` | `.github/prompts/test-data-agent.prompt.md` | Generate fixtures under `tests/fixtures/` |
| `/api-test-agent` | `.github/prompts/api-test-agent.prompt.md` | Generate Axios API specs under `tests/api/` |
| `/ui-test-agent` | `.github/prompts/ui-test-agent.prompt.md` | Generate Playwright specs + Page Objects under `tests/ui/` and `pages/` |
| `/self-healing-agent` | `.github/prompts/self-healing-agent.prompt.md` | Diagnose + fix a failing test |
| `/test-case-agent` | `.github/prompts/test-case-agent.prompt.md` | General-purpose test generator for non-WMS-flow code |

All agents share context from `.github/copilot-instructions.md` (WMS
glossary, module list, conventions) — keep that file accurate as the
suite grows; it's what keeps the agents consistent with each other.

## Typical session
0. (First time, and after significant test-case changes) Export Excel/
   Jira test cases and run `/knowledge-map-builder` — see
   `knowledge-center-agents/README.md` for the export/format caveats.
   Also run `capture-app-snapshots.ts` against a test account, then
   `/app-context-builder` — see `app-context-agent/README.md`.
1. Paste a user story + AC into `/test-orchestrator`.
2. Run `/test-data-agent` for any new fixtures the plan calls for.
3. Run `/api-test-agent` and/or `/ui-test-agent` on the relevant plan rows.
4. Review generated code in the diff view, adjust selectors/endpoint
   assumptions the agent flagged, commit.
5. When CI reports a failure, paste the failure into `/self-healing-agent`.
6. Anytime, ask `/knowledge-query-agent` a functional question directly —
   e.g. "what happens when a pick wave is released with zero inventory?"
