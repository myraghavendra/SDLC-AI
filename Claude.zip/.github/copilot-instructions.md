# Copilot Instructions

This file gives GitHub Copilot Chat context about this repository. Copilot
reads it automatically for every chat request in this workspace (VS Code
setting `github.copilot.chat.codeGeneration.useInstructionFiles` must be
enabled — see README.md).

Fill in the placeholders (`<...>`) below for your actual project. This copy
is pre-filled for a **WMS (Warehouse Management System) SaaS product for
logistics**, tested with **Playwright (UI)** and **Axios (API)**.

## Project overview
- What this repo does: Test automation suite for a WMS SaaS product —
  inbound/receiving, outbound/picking & packing, inventory/cycle count,
  and returns/RMA workflows.
- Primary language(s): TypeScript
- Frameworks: Playwright Test (UI/E2E), Axios (API test client)

## WMS domain glossary (use these terms, don't invent generic ones)
- **ASN** — Advance Shipment Notice (expected inbound shipment)
- **Putaway** — moving received stock from dock to a storage bin
- **Bin / Location** — a storage slot identified by a bin code (e.g. `A1-02-03`)
- **SKU** — stock keeping unit, the item identifier
- **Pick Wave** — a batch of orders released together for picking
- **Pick List** — the sequence of pick tasks generated from a wave
- **Pack Station** — where picked items are packed and labeled for ship
- **Cycle Count** — scheduled partial inventory audit of specific bins/SKUs
- **RMA** — Return Merchandise Authorization
- **Disposition** — decision on returned stock (restock / scrap / quarantine)

## Modules in scope for test generation
1. Inbound / Receiving — ASN receiving, putaway, quality check
2. Outbound / Picking & Packing — allocation, wave/pick list, packing, shipping
3. Inventory / Cycle Count — stock adjustments, bin-to-bin transfers, cycle counts
4. Returns / RMA — return receiving, disposition, restocking

## Test conventions
- UI test framework: Playwright Test, TypeScript, Page Object Model
  (`pages/*.page.ts`), specs under `tests/ui/<module>/*.spec.ts`
- API test framework: Axios as the HTTP client, assertions via Playwright
  Test's `expect` (or your existing runner), specs under
  `tests/api/<module>/*.spec.ts`; a shared `apiClient.ts` wraps Axios with
  base URL + auth headers
- Test data: fixtures under `tests/fixtures/<module>/`, generated/managed
  by the Test Data Agent — do not hardcode production-like IDs
- Run UI tests with: `npx playwright test tests/ui`
- Run API tests with: `npx playwright test tests/api` (or `npm run test:api`)

## Coding conventions
- Use async/await, not `.then()` chains
- No hardcoded waits/sleeps — use Playwright's auto-waiting or explicit
  condition waits; for API polling use retry-with-backoff helpers
- Selectors: prefer `data-testid` attributes over CSS/text selectors where
  available in the app; fall back to accessible role/name locators
- API assertions: validate status code, response schema, and business
  fields relevant to the WMS entity (e.g. bin now shows updated quantity)

## Knowledge Center
`.github/knowledge/functional-knowledge-base.md` (detail) and
`.github/knowledge/knowledge-map.md` (Mermaid mind map overview), if
present, are the authoritative source of documented product behavior —
built from existing Excel/Jira test cases by `/knowledge-map-builder`
(see `knowledge-center-agents/`). Every test-generation and AC-review
agent should consult it before generating/reviewing, and cite the source
test case/Jira key for any rule it relies on. If these files don't
exist yet, agents proceed without them and should say so.

`.github/knowledge/ui-element-map.md`, if present, is real selector/
screen-structure data captured from the live app by
`capture-app-snapshots.ts` and processed by `/app-context-builder` (see
`app-context-agent/`). It's structural (what's on the screen), not
behavioral (what's correct) — keep it distinct from the functional
knowledge base above. `/ui-test-agent` checks it before falling back to
`TODO: confirm selector`.

## Notes for the agents in .github/prompts/
- `test-orchestrator.prompt.md` — reads a use case/user story, classifies
  it into API and/or UI test scope, and produces a test plan.
- `api-test-agent.prompt.md` — generates Axios-based API test specs.
- `ui-test-agent.prompt.md` — generates Playwright UI test specs (POM).
- `test-data-agent.prompt.md` — generates WMS test data/fixtures.
- `test-case-agent.prompt.md` — general-purpose test case generator for
  non-WMS-flow code (utils, services, components).
- `self-healing-agent.prompt.md` — diagnoses and fixes failing
  Playwright/API tests.
All agents should follow the conventions and glossary above so generated
code matches the rest of the suite.
