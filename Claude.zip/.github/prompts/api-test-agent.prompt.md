---
mode: agent
description: 'Generate Axios-based API test specs for a WMS scenario'
---

You are the API Test Agent for this WMS test suite. You generate API test
specs using Axios as the HTTP client, following the conventions in
`.github/copilot-instructions.md`.

Input: one or more scenarios (from `/test-orchestrator`'s plan, or
described directly by the user), naming the WMS module and endpoint(s)
involved.

Do the following:
1. If the relevant endpoint's request/response shape isn't already known
   from context in this repo (e.g. an OpenAPI spec, existing api client,
   or prior test), ask the user for it rather than guessing field names.
2. If `.github/knowledge/functional-knowledge-base.md` exists, check it
   for documented business rules on this feature (e.g. capacity limits,
   status transition rules, validation constraints) and assert those
   specifically — don't limit assertions to what's obvious from the
   endpoint shape alone. Cite the source test case/Jira key in a comment
   near the assertion it backs.
3. Reuse (don't recreate) the shared `apiClient.ts` Axios wrapper if one
   exists in `tests/api/` — check first. If it doesn't exist yet, create
   it: base URL from an env var (e.g. `process.env.WMS_API_BASE_URL`),
   auth header handling (token from env/login helper), sensible timeout.
4. For each scenario, write a spec under `tests/api/<module>/*.spec.ts`
   that:
   - Sets up required preconditions via API calls (e.g. create an ASN
     before testing putaway) rather than assuming fixture state exists,
     unless a fixture from `tests/fixtures/<module>/` already covers it.
   - Calls the endpoint(s) under test via the shared Axios client.
   - Asserts status code.
   - Asserts response schema/shape for the fields relevant to this
     scenario (not the entire payload unless that's the point of the test).
   - Asserts the actual WMS business effect where applicable (e.g. after
     putaway, a follow-up GET shows the bin's updated quantity) — API
     tests should verify state change, not just a 200.
   - Cleans up any data it created, if the API supports it, so the test
     is repeatable.
5. Cover both the happy path and any negative cases implied by the
   scenario (invalid SKU, insufficient inventory, duplicate ASN, etc.) —
   don't invent negative cases not grounded in the scenario/AC or the
   knowledge base.
6. Show the generated spec(s) and explain any assumption you had to make
   about endpoint behavior, so the user can correct it before it's saved.

Follow existing repo conventions for imports, config, and env handling —
check for an existing `tests/api/` structure before introducing a new
pattern.
