/**
 * App snapshot capture — Tier 1 of the App Context Agent.
 *
 * This is plain Playwright automation, NOT an AI agent. It logs into the
 * live WMS app with a test account and walks a list of screens, saving
 * each screen's accessible structure to context-sources/app-snapshots/.
 * The App Context Builder Agent (Copilot) reads those files afterward —
 * Copilot itself never talks to the live app.
 *
 * Credentials: read from env vars only. Never hardcode a username/
 * password here, and never commit real credentials to the repo. Use a
 * dedicated test/QA account, not a real user's login.
 *
 *   WMS_BASE_URL=https://your-app.example.com
 *   WMS_LOGIN_PATH=/login
 *   WMS_TEST_USERNAME=...
 *   WMS_TEST_PASSWORD=...
 *
 * Run: npx playwright test capture-app-snapshots.ts
 * (or `npx ts-node capture-app-snapshots.ts` if run standalone, not as
 * a Playwright test — adjust the runner to match how this repo already
 * invokes Playwright.)
 */

import { chromium } from "playwright";
import * as fs from "fs";
import * as path from "path";

const BASE_URL = process.env.WMS_BASE_URL;
const LOGIN_PATH = process.env.WMS_LOGIN_PATH || "/login";
const USERNAME = process.env.WMS_TEST_USERNAME;
const PASSWORD = process.env.WMS_TEST_PASSWORD;

if (!BASE_URL || !USERNAME || !PASSWORD) {
  throw new Error(
    "Set WMS_BASE_URL, WMS_TEST_USERNAME, WMS_TEST_PASSWORD env vars before running. " +
      "Never hardcode credentials in this file."
  );
}

// Edit this list to match your app's actual screens/routes.
// One entry per screen you want captured.
const SCREENS: { name: string; path: string }[] = [
  { name: "inbound-receiving", path: "/inbound/receiving" },
  { name: "inbound-putaway", path: "/inbound/putaway" },
  { name: "outbound-pick-wave", path: "/outbound/pick-wave" },
  { name: "outbound-pack-station", path: "/outbound/pack-station" },
  { name: "inventory-cycle-count", path: "/inventory/cycle-count" },
  { name: "returns-rma", path: "/returns/rma" },
];

const OUT_DIR = path.join(__dirname, "..", "context-sources", "app-snapshots");

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });

  const browser = await chromium.launch();
  const context = await browser.newContext();
  const page = await context.newPage();

  // --- Login ---
  // Adjust selectors to match your actual login form.
  await page.goto(`${BASE_URL}${LOGIN_PATH}`);
  await page.getByLabel(/username|email/i).fill(USERNAME!);
  await page.getByLabel(/password/i).fill(PASSWORD!);
  await page.getByRole("button", { name: /log in|sign in/i }).click();
  await page.waitForLoadState("networkidle");

  // --- Walk each screen and capture structure ---
  for (const screen of SCREENS) {
    try {
      await page.goto(`${BASE_URL}${screen.path}`);
      await page.waitForLoadState("networkidle");

      const title = await page.title();
      const url = page.url();

      // All elements carrying a data-testid — the selectors your Page
      // Objects should actually use.
      const testIdElements = await page.$$eval("[data-testid]", (els) =>
        els.map((el) => ({
          testId: el.getAttribute("data-testid"),
          tag: el.tagName.toLowerCase(),
          role: el.getAttribute("role"),
          text: (el.textContent || "").trim().slice(0, 80),
          type: el.getAttribute("type"),
        }))
      );

      // Accessible name/role tree — useful when data-testid is missing
      // and Playwright's getByRole/getByLabel locators are the fallback.
      const ariaSnapshot = await page.locator("body").ariaSnapshot();

      const snapshot = {
        screen: screen.name,
        url,
        title,
        capturedAt: new Date().toISOString(),
        testIdElements,
        ariaSnapshot,
      };

      const outFile = path.join(OUT_DIR, `${screen.name}.json`);
      fs.writeFileSync(outFile, JSON.stringify(snapshot, null, 2));
      console.log(`Captured ${screen.name} -> ${outFile}`);

      // Optional: screenshot for human review. Skip if screens may show
      // sensitive real data — use a test/sandbox environment only.
      await page.screenshot({
        path: path.join(OUT_DIR, `${screen.name}.png`),
        fullPage: true,
      });
    } catch (err) {
      console.error(`Failed to capture ${screen.name}:`, err);
    }
  }

  await browser.close();
}

main();
