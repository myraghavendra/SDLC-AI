# App Context Agent — Read the Live WMS App into Copilot Context

Answers "can an agent read our app's URL and build context from it?" —
yes, but Copilot Chat has no built-in web-browsing tool, so it can't do
this on its own. This folder implements **Tier 1**, which works today
with nothing extra to install or approve, and documents **Tier 2** as an
upgrade path if your org later allows it.

## Tier 1 (built here) — capture, then let Copilot read it

```
capture-app-snapshots.ts   (plain Playwright, not AI)
        │  logs into the live app with a test account,
        │  walks a list of screens, saves each screen's
        │  data-testid elements + accessible structure
        ▼
context-sources/app-snapshots/*.json  (+ .png screenshots)
        │
        ▼
/app-context-builder   (Copilot agent — only reads the captured files)
        │
        ▼
.github/knowledge/ui-element-map.md
   - real selectors per screen, cited from the capture
   - resolves `TODO: confirm selector` left by /ui-test-agent
   - flags screens with no data-testid coverage
```

Copilot never touches the live app in this tier — it only reads static
files that Playwright already captured. That's what makes this
compatible with "GitHub Copilot only": the web-reading step is your
existing test tool (Playwright), the reasoning step is Copilot.

### Setup
1. Set env vars for a **dedicated test/QA account** (never a real user's
   login, never hardcoded in the script):
   ```
   WMS_BASE_URL=https://your-app.example.com
   WMS_LOGIN_PATH=/login
   WMS_TEST_USERNAME=...
   WMS_TEST_PASSWORD=...
   ```
2. Edit the `SCREENS` list in `capture-app-snapshots.ts` to match your
   app's actual routes — the placeholder list uses generic WMS paths
   that almost certainly don't match your real app.
3. Add `context-sources/app-snapshots/` to `.gitignore` if the captured
   screenshots or snapshot JSON could contain real customer/order data —
   run this against a sandbox/staging environment with synthetic data,
   not production.
4. Run the capture script, then run `/app-context-builder` in Copilot
   Chat.
5. Re-run both whenever the app's UI changes meaningfully — this is a
   snapshot, not a live sync, same caveat as the Excel/Jira knowledge
   center.

## Tier 2 (not built — needs org approval) — live browsing during chat

VS Code's Copilot Chat supports MCP tools, and Microsoft publishes an
official **Playwright MCP server** that gives Copilot Chat a real
navigate/click/log-in/read-the-page tool it can call *during* a chat
session — no capture step, no separate script, it browses the live app
on request.

This is more powerful but has real prerequisites:
- Your org has to allow installing an MCP server inside Copilot Chat —
  check with whoever administers your Copilot license before assuming
  this is available.
- Login credentials still need careful handling: use an env-var-based
  test account the MCP server reads locally, never type a password
  into the chat itself.
- Because it's live, it can browse deeper/more adaptively than a fixed
  capture list — but every run touches the real app, so treat it like
  any other automated traffic against that environment (rate limits,
  test-account-only, avoid production).

If/when your org approves this, the natural next step is to add the
Playwright MCP server in VS Code settings and give `/app-context-builder`
(or a new "live" variant of it) permission to call its navigate/snapshot
tools directly, instead of reading pre-captured files. Worth revisiting
once Tier 1 has proven useful — don't build Tier 2 speculatively before
that.

## Files in this folder
| File | Role |
|---|---|
| `capture-app-snapshots.ts` | Playwright script — logs in, captures screen structure (not AI) |
| `app-context-builder.prompt.md` | Copilot agent — builds `.github/knowledge/ui-element-map.md` from captures |

Same discovery caveat as the other extra folders: copy
`app-context-builder.prompt.md` into `.github/prompts/` (or register
this folder as an extra prompt location) to actually run it as a slash
command — see the root `README.md`.
