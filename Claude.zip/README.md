# Copilot Test Agents — WMS SaaS Test Automation

This repo is set up so GitHub Copilot Chat in VS Code can act as a set of
reusable "agents" for testing a WMS (logistics) SaaS product: reading a
use case, planning API (Axios) and UI (Playwright) test coverage,
generating the tests, generating fixtures, and self-healing failures. See
`.github/TESTING-FLOW.md` for the full orchestration flow and which agent
to run when.

## Files
- `.github/copilot-instructions.md` — WMS domain glossary, module list,
  and Playwright/Axios conventions Copilot reads on every chat request in
  this workspace. Update this as the real app's conventions solidify.
- `.github/TESTING-FLOW.md` — end-to-end flow diagram across all agents.
- `.github/prompts/test-orchestrator.prompt.md` — reads a use case, plans
  API vs UI test scope.
- `.github/prompts/api-test-agent.prompt.md` — generates Axios API tests.
- `.github/prompts/ui-test-agent.prompt.md` — generates Playwright UI
  tests (Page Object Model).
- `.github/prompts/test-data-agent.prompt.md` — generates WMS fixtures.
- `.github/prompts/self-healing-agent.prompt.md` — diagnoses and fixes a
  failing Playwright/API test.
- `.github/prompts/test-case-agent.prompt.md` — general-purpose test
  generator for non-WMS-flow code (utils, services, components).
- `copilot-agents-extended/` — 13 general engineering agents (code
  review, security review, docs, etc.) — see its own README for the
  discovery caveat.
- `knowledge-center-agents/` — builds a Functional Knowledge Center +
  Mermaid mind map from existing Excel/Jira test cases, and answers
  functional questions from it; wired into the test-generation agents
  above as shared context. See its README for real limitations (Copilot
  can't read `.xlsx` directly, no built-in live Jira connection).
- `app-context-agent/` — reads the live WMS app into context: a
  Playwright script (not AI) captures real screen structure/selectors
  from a test-account login, and a Copilot agent turns that into
  `ui-element-map.md`, which `/ui-test-agent` uses instead of guessing
  selectors. See its README — Copilot can't browse a live URL on its
  own, so this documents both the capture-first approach that works
  today and an MCP-based live-browsing upgrade path for later.
- `rovo-agents/` — a separate spec for Atlassian Rovo (Jira/Xray), not
  part of the Copilot flow — different platform, kept for reference.

## One-time setup in VS Code
1. Install the **GitHub Copilot** and **GitHub Copilot Chat** extensions.
2. Sign in with your org's Copilot-licensed GitHub account.
3. Open VS Code Settings (`Ctrl+,`) and enable:
   - `chat.promptFiles` → `true` (lets Copilot Chat discover files in
     `.github/prompts/`)
   - `github.copilot.chat.codeGeneration.useInstructionFiles` → `true`
     (makes Copilot read `.github/copilot-instructions.md` automatically)
4. Reload the window if the settings don't take effect immediately.

## How to run the agents
1. Open Copilot Chat (`Ctrl+Alt+I` or the chat icon).
2. Type `/` — you should see the six agents in `.github/prompts/`
   (`test-orchestrator`, `test-data-agent`, `api-test-agent`,
   `ui-test-agent`, `self-healing-agent`, `test-case-agent`) in the
   suggestion list. The 13 agents in `copilot-agents-extended/`, the 2 in
   `knowledge-center-agents/`, and the 1 in `app-context-agent/` need an
   extra step first — see below.
3. Start with `/test-orchestrator` and paste in a user story + acceptance
   criteria — it produces a test plan and tells you which agent to run
   next (see `.github/TESTING-FLOW.md`).
4. For `/self-healing-agent`, paste the error/stack trace into the chat
   message along with the slash command.
5. Review Copilot's proposed changes and accept/reject in the diff view
   before saving.

If the prompt files don't show up under `/`, double-check step 3 of
setup above — that setting is the most common reason they're invisible.

**Agents outside `.github/prompts/`**: `copilot-agents-extended/`,
`knowledge-center-agents/`, and `app-context-agent/` are kept separate
on purpose (general engineering agents vs. WMS-flow agents vs.
knowledge-center agents vs. live-app-context agent). Copilot Chat only
auto-discovers `.github/prompts/` by default, so
either copy those `.prompt.md` files in there too, or register the
extra folders as additional prompt locations if your VS Code/Copilot
version supports it — see each folder's own README for details.

## Next steps
- Fill in `.github/copilot-instructions.md` with your actual stack.
- Push this folder to a new GitHub repo (or copy `.github/` into an
  existing repo) so the whole team gets the same agents.
- Once this is working well interactively, we can look at wiring the
  Self-Healing Agent into CI (e.g. auto-triggered on a failed test job)
  using GitHub Actions + the Copilot coding agent — that's a bigger step,
  only worth it once the interactive version proves useful.
